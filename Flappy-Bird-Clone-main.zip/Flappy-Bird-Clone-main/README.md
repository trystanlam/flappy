# Flappy-Bird-Clone
Flappy Bird Clone game I made in unity to refresh unity 2d concepts.

Check out the demo here: https://youtu.be/B-Yq-UkDJw0

Try out the game on Itch.io here: https://solidsoldier12.itch.io/flappy-bird-clone